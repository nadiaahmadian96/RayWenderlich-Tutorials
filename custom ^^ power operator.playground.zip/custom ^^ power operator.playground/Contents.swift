//Swift has a set of pre-defined operators to perform arithmetic or logic operations. It also allows the creation of custom operators, either unary or binary.
//Define and implement a custom ^^ power operator with the following specifications:
//Takes two Ints as parameters.
//Returns the first parameter raised to the power of the second.
//Correctly evaluates the equation using the standard algebraic order of operations.
//Ignores the potential for overflow errors.

import Foundation

precedencegroup ExponentPrecedence {
  higherThan: MultiplicationPrecedence
  associativity: right
}
infix operator ^^: ExponentPrecedence


func ^^(base: Int, exponent: Int) -> Int {
  let l = Double(base)
  let r = Double(exponent)
  let p = pow(l, r)
  return Int(p)
}

//Note that since the code doesn't take overflows into account, if the operation produces a result that Int can't represent, such as a value greater than Int.max, then a runtime error occurs.
